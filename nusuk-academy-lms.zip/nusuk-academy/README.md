# Nusuk Academy LMS

A full-stack Learning Management System for **Nusuk Academy**, built for Alim and
Alima Islamic studies courses: live Zoom classes, recorded lectures, resources,
progress tracking, payments, and role-based dashboards for Super Admins,
Teachers, and Students.

**Stack:** Next.js 14 (App Router) · TypeScript · Prisma ORM · SQLite (dev) /
PostgreSQL (prod) · NextAuth (credentials/JWT) · Tailwind CSS.

Read **`SCOPE.md`** first — it explains exactly what is fully working out of the
box versus what is scaffolded for you to finish (payment gateway, Zoom API,
quizzes, certificates, full multi-language UI).

---

## 1. Folder structure

```
nusuk-academy/
├── prisma/
│   ├── schema.prisma        # Full data model (users, courses, modules, classes,
│   │                         #  videos, live classes, resources, payments, etc.)
│   └── seed.ts               # Creates the first Super Admin + sample courses
├── src/
│   ├── app/
│   │   ├── (public pages)    # /, /login, /forgot-password, /reset-password
│   │   ├── change-password/  # Forced password change flow
│   │   ├── complete-profile/ # Forced first-login profile completion
│   │   ├── admin/            # Super Admin dashboard, users, courses, payments
│   │   ├── teacher/          # Teacher dashboard, course management
│   │   ├── student/          # Student dashboard, course viewer, payments
│   │   └── api/               # All REST endpoints (see below)
│   ├── components/           # Shared UI (DashboardShell, CourseManager, etc.)
│   ├── lib/                  # auth.ts, prisma.ts, session.ts, permissions.ts
│   └── types/                # NextAuth type augmentation
├── .env.example
└── package.json
```

## 2. Install & run locally

Requirements: Node.js 18.18+ and npm.

```bash
cd nusuk-academy
npm install
cp .env.example .env          # defaults work as-is for local SQLite dev
npx prisma migrate dev --name init
npm run seed                  # creates the first Super Admin account
npm run dev
```

Open http://localhost:3000.

The seed script prints your Super Admin username/password to the terminal
(defaults to `admin` / `ChangeMe123!` unless you set `SEED_ADMIN_USERNAME` /
`SEED_ADMIN_PASSWORD` env vars before seeding). You'll be forced to set a new
password on first login.

## 3. Creating your first admin account

Already handled by `npm run seed` above. To create additional Super Admins,
either re-run the seed with different env vars, or use Prisma Studio:

```bash
npx prisma studio
```

...and manually set a user's `role` to `SUPER_ADMIN` (their password must
still be bcrypt-hashed — easiest is to create them through the app as a
teacher/student first, then promote via Studio, or extend the seed script).

## 4. How to upload courses (as Super Admin or assigned Teacher)

1. Log in → **Courses** → **Create a course** (choose Alim or Alima).
2. Open the course → add **Modules** (e.g. "Module 1 - Aqeedah").
3. Inside a module, add **Classes** (e.g. "Class 1").
4. On each class, use the buttons to:
   - **Add recorded video** — paste an embeddable URL (YouTube unlisted,
     Google Drive preview link, Bunny.net, etc. — see `MEDIA.md`).
   - **Add live Zoom class** — paste the Zoom meeting link + schedule time.
   - **Add resource** — paste a public file URL (PDF, doc, image, audio).
5. As Super Admin, assign **Teachers** to a course from the course page so
   they can manage it too.

## 5. How students use the platform

1. Admin creates a student account (**Admin → Users → Create account**),
   which generates a username + temporary password to share securely.
2. Student logs in, is forced to **set a new password**, then **complete
   their profile** (name, gender, DOB, contact info, course selection).
   - The system automatically restricts male students to the Alim course
     and female students to the Alima course.
3. Enrollment starts as `PENDING`. Student goes to **Payments**, sees the
   academy's bank details, and submits proof of payment.
4. Admin reviews the payment in **Admin → Payments** and approves it, which
   activates the enrollment.
5. Student can now open the course: watch recorded classes, join live Zoom
   sessions, download resources, mark classes complete, and track progress.

## 6. Environment variables

See `.env.example`. For local dev you only need `DATABASE_URL` (SQLite file)
and `NEXTAUTH_SECRET`/`NEXTAUTH_URL`. Generate a secret with:

```bash
openssl rand -base64 32
```

## 7. Database

`prisma/schema.prisma` is the source of truth — see it for every table,
field, relationship, and index (Users, Courses, Modules, Classes, Videos,
LiveClasses, Resources, Enrollments, ClassProgress, Certificates, Payments,
PaymentSettings, Announcements, Notifications, Messages, AuditLog).

Run `npx prisma studio` any time to browse/edit data visually.

## 8. Deployment

See `DEPLOYMENT.md` for a full free-tier deployment walkthrough (Vercel +
Neon/Supabase Postgres).

## 9. Security notes already implemented

- Passwords hashed with bcrypt (12 rounds), never stored in plain text.
- Role-based route protection via `middleware.ts` (`/admin`, `/teacher`,
  `/student` prefixes) plus server-side `requireUser()` checks on every page.
- Every API route re-validates the session and role server-side — the UI
  never assumes trust.
- Gender ↔ course-type enrollment rule enforced server-side in two places
  (`complete-profile` and `enroll` APIs), not just in the UI.
- Zod validation on all API inputs.
- Forced password change + forced profile completion on first login.
- Audit log table records user create/update/delete actions.

See `SCOPE.md` for security items that still need attention before a real
production launch (rate limiting, file-upload virus scanning, CSRF review
for non-NextAuth forms, etc.).
