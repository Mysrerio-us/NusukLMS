# Scope: what's real vs. what's scaffolded

This was built as a working core, not a mockup — every feature listed under
"Fully working" runs end-to-end against a real database with no placeholder
data. But the original request covers dozens of subsystems that would
normally take a team months (payment gateways, Zoom API, certificates,
quizzes, 3-language i18n, messaging). Building all of that to production
quality in one pass isn't realistic, so here's exactly where things stand.

## ✅ Fully working

- **Auth**: username/password login (NextAuth + JWT), bcrypt hashing,
  forced password change on first login, forgot/reset password flow.
- **Roles**: Super Admin, Teacher, Student — enforced in middleware AND on
  every API route (not just hidden UI).
- **Admin**: create student/teacher accounts (auto-generated username +
  temp password), list/filter users by role/gender, disable/delete users,
  dashboard stats (students by gender/course, teachers, revenue).
- **Course hierarchy**: Course → Module → Class, full CRUD, admin or
  assigned teacher only.
- **Gender/course rule**: male → Alim, female → Alima, enforced server-side
  at profile completion and admin enrollment — not just a UI restriction.
- **Recorded video**: attach an embeddable URL + optional download link to
  any class; renders in an iframe player for students.
- **Live Zoom classes**: attach a link + schedule; students get a
  "Join Live Class" button.
- **Resources**: attach files (by URL) to a course/module/class; students
  see them listed with download links.
- **Progress tracking**: students mark classes complete; dashboard shows a
  real percentage bar computed from the database, per enrolled course.
- **Payments**: bank-transfer workflow — admin sets bank details, student
  submits proof + reference, admin approves/rejects, approval activates
  enrollment. Full history on both sides.
- **Announcements**: teachers/admins post to a course; students see them on
  the course page; a Notification row is created for each enrolled student.
- **Search API**: keyword + course + teacher filtering across classes
  (`/api/search`), ready to wire into a search UI.
- **Audit log table**: user create/update/delete actions are recorded.

## 🧩 Scaffolded — schema + API shape exist, needs finishing

These have real database tables and, in most cases, a working API, but no
full UI or external integration yet:

- **Stripe/card payments**: `Payment.method` supports `STRIPE`; no webhook
  handler is wired up yet (bank-transfer flow is the complete path today).
- **Zoom API integration**: currently link-based (admin pastes a Zoom URL
  they created manually). Auto-creating Zoom meetings via their API is a
  documented next step, not implemented — it requires a paid Zoom account
  and OAuth app approval that I can't provision on your behalf.
- **Notifications UI**: `Notification` rows are created correctly on new
  class/resource/announcement/payment events, but there's no bell-icon
  inbox page yet — only the underlying data and API.
- **Messaging**: `Message` table exists; no conversation UI built.
- **Certificates**: `Certificate` table exists; no PDF generation wired up.
- **Multi-language (EN/AR/SI)**: Tailwind config includes an Arabic font
  and `dir="rtl"` support is set up, but the UI strings are English-only —
  no i18n library (e.g. `next-intl`) is wired in yet.
- **Quizzes/assignments/attendance/calendar**: not in the schema — would be
  additive tables (`Quiz`, `Question`, `Submission`, `AttendanceRecord`)
  following the same Prisma patterns already established.

## 📁 File uploads

Rather than building a custom file server (fragile on free hosting tiers
with ephemeral disks), resources/videos/payment-proofs are stored as **URLs
you paste in** after uploading to any storage you like — Google Drive,
Cloudinary free tier, Supabase Storage, Bunny.net, YouTube unlisted, etc.
See `MEDIA.md` for the recommended free options and exact URL formats. This
is a deliberate, documented choice, not an oversight — direct-to-storage
upload (skipping your server entirely) is both cheaper and more scalable
than routing large files through the Node process.

## 🔒 Before a real production launch, also add

- Rate limiting on auth and payment-submission endpoints.
- CAPTCHA or similar on login/forgot-password to slow brute force.
- Server-side file-type/size validation if you later add direct uploads.
- A real transactional email provider wired into forgot-password (currently
  logs the reset link to the console in dev — see `route.ts` comments).
- Backups: enable automatic backups on whichever Postgres host you deploy
  to (Neon/Supabase both offer this on paid tiers; free tiers vary).
