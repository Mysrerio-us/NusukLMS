# Deployment Guide — Free Tier (Vercel + Neon/Supabase Postgres)

This deploys the Next.js app to **Vercel** (free Hobby tier) with a
**PostgreSQL** database on **Neon** or **Supabase** (both have permanent
free tiers, unlike Railway's trial-only free tier).

## 1. Push the code to GitHub

```bash
cd nusuk-academy
git init
git add .
git commit -m "Initial commit: Nusuk Academy LMS"
gh repo create nusuk-academy --private --source=. --push
# or create a repo on github.com and `git remote add origin ...; git push`
```

## 2. Create a free Postgres database

**Option A — Neon (recommended, generous free tier):**
1. Go to https://neon.tech → sign up → "Create a project".
2. Copy the connection string shown (starts with `postgresql://`).

**Option B — Supabase:**
1. Go to https://supabase.com → new project.
2. Project Settings → Database → copy the "Connection string" (URI, with
   `?sslmode=require` appended if not already there).

## 3. Switch Prisma to PostgreSQL

Edit `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"   // was "sqlite"
  url      = env("DATABASE_URL")
}
```

Commit this change.

## 4. Deploy to Vercel

1. Go to https://vercel.com → "Add New Project" → import your GitHub repo.
2. In **Environment Variables**, add:
   - `DATABASE_URL` — your Neon/Supabase connection string
   - `NEXTAUTH_SECRET` — output of `openssl rand -base64 32`
   - `NEXTAUTH_URL` — your Vercel URL, e.g. `https://nusuk-academy.vercel.app`
     (you can update this after the first deploy once you know the URL)
3. Build command: `npm run build` (already runs `prisma generate` first —
   see `package.json`). Vercel detects Next.js automatically.
4. Click **Deploy**.

## 5. Run the first migration against production

After the first successful deploy, run the migration once from your local
machine, pointed at the production database:

```bash
DATABASE_URL="your-neon-or-supabase-url" npx prisma migrate deploy
DATABASE_URL="your-neon-or-supabase-url" SEED_ADMIN_USERNAME="admin" SEED_ADMIN_PASSWORD="ChooseAStrongPassword!" npx tsx prisma/seed.ts
```

This creates your production Super Admin account and sample Alim/Alima
courses.

## 6. Custom domain (optional, free)

Vercel → Project → Settings → Domains → add your domain and follow the DNS
instructions (works with any registrar, including free ones you may already
own).

## 7. Ongoing deploys

Every `git push` to your main branch auto-deploys on Vercel. For future
schema changes:

```bash
npx prisma migrate dev --name your_change   # locally, against SQLite or a dev DB
git push                                     # Vercel builds
DATABASE_URL="prod-url" npx prisma migrate deploy   # apply to prod DB
```

## Free-tier limits to be aware of

- **Vercel Hobby**: fine for an academy-scale app; watch serverless function
  execution time limits if you later add heavy video processing (you
  shouldn't need to — videos are hosted externally, see `MEDIA.md`).
- **Neon free tier**: database "sleeps" after inactivity and wakes on the
  next request (a few hundred ms delay) — fine for this use case.
- **Supabase free tier**: project pauses after 1 week of inactivity unless
  you have at least weekly traffic; Neon doesn't have this restriction.

## Alternative: Render (single free web service)

If you'd rather not split frontend/DB across two providers, Render's free
tier can host both a Postgres instance and the Next.js app, though the free
web service sleeps after 15 minutes of inactivity (slow first load after
idle). Steps are analogous: create a Render Postgres instance, deploy the
repo as a Web Service with `npm run build` / `npm start`, set the same
environment variables as above.
