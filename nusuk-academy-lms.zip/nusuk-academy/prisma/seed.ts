import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminUsername = process.env.SEED_ADMIN_USERNAME || "admin";
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || "ChangeMe123!";

  const existingAdmin = await prisma.user.findUnique({ where: { username: adminUsername } });
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(adminPassword, 12);
    await prisma.user.create({
      data: {
        username: adminUsername,
        email: "admin@nusukacademy.org",
        fullName: "Nusuk Academy Admin",
        role: "SUPER_ADMIN",
        passwordHash,
        mustChangePassword: true,
        profileCompleted: true,
        isActive: true,
      },
    });
    console.log(`✅ Super Admin created — username: "${adminUsername}", temporary password: "${adminPassword}"`);
    console.log("   You will be asked to change this password on first login.");
  } else {
    console.log("ℹ️  Super Admin already exists, skipping.");
  }

  const alim = await prisma.course.upsert({
    where: { slug: "alim-course" },
    update: {},
    create: {
      title: "Alim Course",
      slug: "alim-course",
      type: "ALIM",
      description: "A structured Islamic scholarship program for male students.",
      feeAmount: 0,
    },
  });

  const alima = await prisma.course.upsert({
    where: { slug: "alima-course" },
    update: {},
    create: {
      title: "Alima Course",
      slug: "alima-course",
      type: "ALIMA",
      description: "A structured Islamic scholarship program for female students.",
      feeAmount: 0,
    },
  });

  for (const course of [alim, alima]) {
    const existingModule = await prisma.module.findFirst({ where: { courseId: course.id } });
    if (!existingModule) {
      await prisma.module.create({
        data: { courseId: course.id, title: "Module 1 - Aqeedah", order: 0 },
      });
    }
  }

  await prisma.paymentSettings.upsert({
    where: { id: "singleton" },
    update: {},
    create: {
      id: "singleton",
      bankName: "Your Bank Name",
      accountName: "Nusuk Academy",
      accountNumber: "0000000000",
      instructions: "Please include your username as the payment reference.",
    },
  });

  console.log("✅ Sample Alim & Alima courses and payment settings created.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
