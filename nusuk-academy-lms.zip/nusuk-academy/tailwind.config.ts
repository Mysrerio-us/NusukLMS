import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        // Calm, professional Islamic-education palette
        emerald: {
          50: "#eefaf5", 100: "#d5f1e6", 200: "#ade3ce", 300: "#78ceb1",
          400: "#46b393", 500: "#28977a", 600: "#1c7a63", 700: "#1a6252",
          800: "#194f43", 900: "#164239", 950: "#0a2620",
        },
        sand: {
          50: "#faf8f3", 100: "#f3ede1", 200: "#e6d9c1", 300: "#d6c19a",
          400: "#c4a672", 500: "#b28f55", 600: "#977347", 700: "#7a5c3c",
          800: "#644c35", 900: "#54402f",
        },
        ink: {
          50: "#f4f6f6", 100: "#e3e8e8", 400: "#6f8285", 700: "#334042",
          800: "#22292b", 900: "#171c1d",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
        arabic: ["var(--font-arabic)", "serif"],
      },
      borderRadius: { xl2: "1.25rem" },
    },
  },
  plugins: [],
};
export default config;
