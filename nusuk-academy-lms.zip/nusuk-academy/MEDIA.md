# Video & Resource Hosting (Free Options)

The LMS stores **URLs**, not files. Upload once to one of these, then paste
the resulting link into the admin/teacher "Add video" or "Add resource"
form.

## Recorded videos

| Option | Free tier | Embed URL format |
|---|---|---|
| **YouTube (Unlisted)** | Unlimited, free | `https://www.youtube.com/embed/VIDEO_ID` |
| **Google Drive** | 15 GB free | Share → "Anyone with link" → use `https://drive.google.com/file/d/FILE_ID/preview` |
| **Bunny.net Stream** | Free trial credit, then pay-as-you-go (very cheap) | Their dashboard gives you a direct iframe embed URL |
| **Cloudinary** | 25 GB/25 credits free | Auto-generates a streaming URL on upload |

**Recommended:** YouTube Unlisted for zero cost and reliable playback —
students can't find the video via search, only via the direct link you
paste into the LMS. For a more "branded" feel with no YouTube UI, use
Google Drive's `/preview` embed instead.

Download links: only fill in "download URL" if you want students to
download the file directly. For Google Drive, the direct-download format is
`https://drive.google.com/uc?export=download&id=FILE_ID`.

## Documents, PDFs, images, audio (Resources)

- **Google Drive** (share link, same as above) — simplest, free, generous
  storage.
- **Supabase Storage** — 1 GB free on the Supabase free tier, gives you a
  clean public URL; pairs naturally if you're already using Supabase
  Postgres for the database (see `DEPLOYMENT.md`).
- **Cloudinary** — good for images specifically, free tier is generous.

## Payment proof screenshots

Same options apply — Google Drive or Imgur (for images) are the fastest for
students to use without creating new accounts.

## If you outgrow URL-pasting

Once you have real traffic, the natural next step is a proper upload widget
(e.g. `@uploadthing/react`, or direct-to-S3/Supabase presigned uploads) so
teachers don't have to leave the LMS to host a file. The `Resource.fileUrl`
and `Video.videoUrl` fields don't need to change — only how they get
populated.
