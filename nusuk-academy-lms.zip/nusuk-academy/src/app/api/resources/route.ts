import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { canManageCourse, courseIdForModule, courseIdForClass } from "@/lib/permissions";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const courseId = searchParams.get("courseId") ?? undefined;
  const type = searchParams.get("type") ?? undefined;
  const q = searchParams.get("q") ?? undefined;

  const resources = await prisma.resource.findMany({
    where: {
      courseId: courseId || undefined,
      type: (type as any) || undefined,
      title: q ? { contains: q } : undefined,
    },
    orderBy: { createdAt: "desc" },
    include: { course: { select: { title: true } } },
  });
  return NextResponse.json({ resources });
}

// File upload itself: in production, upload the binary client-side directly
// to your storage provider (Cloudinary/S3/Supabase Storage — see MEDIA.md)
// and pass the resulting public fileUrl here. This keeps the Next.js server
// stateless and free-tier friendly (no large file bodies through the API).
const schema = z.object({
  title: z.string().min(1),
  type: z.enum(["PDF", "DOCUMENT", "IMAGE", "AUDIO", "LINK", "OTHER"]),
  fileUrl: z.string().url(),
  category: z.string().optional(),
  courseId: z.string().optional(),
  moduleId: z.string().optional(),
  classId: z.string().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || !["SUPER_ADMIN", "TEACHER"].includes(user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  let courseId = body.data.courseId ?? null;
  if (!courseId && body.data.moduleId) courseId = await courseIdForModule(body.data.moduleId);
  if (!courseId && body.data.classId) courseId = await courseIdForClass(body.data.classId);
  if (!courseId || !(await canManageCourse(user, courseId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const resource = await prisma.resource.create({
    data: { ...body.data, courseId, uploadedById: user.id },
  });

  const enrolled = await prisma.enrollment.findMany({
    where: { courseId, status: "ACTIVE" },
    select: { studentId: true },
  });
  if (enrolled.length) {
    await prisma.notification.createMany({
      data: enrolled.map((e) => ({
        userId: e.studentId,
        type: "NEW_RESOURCE" as const,
        title: "New resource available",
        body: resource.title,
        link: `/student/courses/${courseId}`,
      })),
    });
  }

  return NextResponse.json({ resource }, { status: 201 });
}
