import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { canManageCourse, courseIdForModule } from "@/lib/permissions";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user || !["SUPER_ADMIN", "TEACHER"].includes(user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const courseId = await courseIdForModule(params.id);
  if (!courseId || !(await canManageCourse(user, courseId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  const data = await req.json();
  const module_ = await prisma.module.update({
    where: { id: params.id },
    data: { title: data.title, description: data.description, order: data.order },
  });
  return NextResponse.json({ module: module_ });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user || !["SUPER_ADMIN", "TEACHER"].includes(user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const courseId = await courseIdForModule(params.id);
  if (!courseId || !(await canManageCourse(user, courseId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  await prisma.module.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
