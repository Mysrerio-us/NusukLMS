import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { canManageCourse } from "@/lib/permissions";

const schema = z.object({
  courseId: z.string(),
  title: z.string().min(2),
  description: z.string().optional(),
  order: z.number().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || !["SUPER_ADMIN", "TEACHER"].includes(user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  if (!(await canManageCourse(user, body.data.courseId))) {
    return NextResponse.json({ error: "You are not assigned to this course" }, { status: 403 });
  }

  const module_ = await prisma.module.create({ data: body.data });
  return NextResponse.json({ module: module_ }, { status: 201 });
}
