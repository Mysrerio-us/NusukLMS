import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

const schema = z.object({
  classId: z.string(),
  completed: z.boolean(),
  watchedSec: z.number().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== "STUDENT") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const progress = await prisma.classProgress.upsert({
    where: { studentId_classId: { studentId: user.id, classId: body.data.classId } },
    update: {
      completed: body.data.completed,
      watchedSec: body.data.watchedSec,
      completedAt: body.data.completed ? new Date() : null,
    },
    create: {
      studentId: user.id,
      classId: body.data.classId,
      completed: body.data.completed,
      watchedSec: body.data.watchedSec ?? 0,
      completedAt: body.data.completed ? new Date() : null,
    },
  });
  return NextResponse.json({ progress });
}
