import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { canManageCourse, courseIdForClass } from "@/lib/permissions";

// Videos are hosted externally (YouTube unlisted, Google Drive, Bunny.net, etc.)
// This endpoint just records the URL + metadata against a Class.
// See MEDIA.md for recommended free hosting options and embed formats.
const schema = z.object({
  classId: z.string(),
  title: z.string().min(2),
  description: z.string().optional(),
  videoUrl: z.string().url(),
  thumbnailUrl: z.string().url().optional().or(z.literal("")),
  allowDownload: z.boolean().default(false),
  downloadUrl: z.string().url().optional().or(z.literal("")),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || !["SUPER_ADMIN", "TEACHER"].includes(user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const courseId = await courseIdForClass(body.data.classId);
  if (!courseId || !(await canManageCourse(user, courseId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const video = await prisma.video.upsert({
    where: { classId: body.data.classId },
    update: { ...body.data, teacherId: user.id },
    create: { ...body.data, teacherId: user.id },
  });
  return NextResponse.json({ video }, { status: 201 });
}
