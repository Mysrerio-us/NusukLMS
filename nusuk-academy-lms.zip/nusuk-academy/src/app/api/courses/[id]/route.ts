import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const course = await prisma.course.findUnique({
    where: { id: params.id },
    include: {
      modules: {
        orderBy: { order: "asc" },
        include: {
          classes: {
            orderBy: { order: "asc" },
            include: { video: true, liveClass: true, resources: true },
          },
          resources: true,
        },
      },
      resources: true,
      teachers: { include: { teacher: { select: { id: true, fullName: true, username: true } } } },
    },
  });
  if (!course) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ course });
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user || user.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const data = await req.json();
  const course = await prisma.course.update({
    where: { id: params.id },
    data: {
      title: data.title,
      description: data.description,
      feeAmount: data.feeAmount,
      currency: data.currency,
      isPublished: data.isPublished,
      coverImageUrl: data.coverImageUrl,
    },
  });
  return NextResponse.json({ course });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user || user.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  await prisma.course.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
