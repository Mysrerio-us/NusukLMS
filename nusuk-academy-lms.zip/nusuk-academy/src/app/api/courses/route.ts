import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

export async function GET() {
  const courses = await prisma.course.findMany({
    orderBy: { createdAt: "desc" },
    include: { modules: { select: { id: true } }, _count: { select: { enrollments: true } } },
  });
  return NextResponse.json({ courses });
}

const schema = z.object({
  title: z.string().min(2),
  type: z.enum(["ALIM", "ALIMA"]),
  description: z.string().optional(),
  feeAmount: z.number().min(0).default(0),
  currency: z.string().default("USD"),
});

function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const { title, type, description, feeAmount, currency } = body.data;
  let slug = slugify(title);
  const existing = await prisma.course.findUnique({ where: { slug } });
  if (existing) slug = `${slug}-${Date.now().toString(36)}`;

  const course = await prisma.course.create({
    data: { title, type, description, feeAmount, currency, slug },
  });
  return NextResponse.json({ course }, { status: 201 });
}
