import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { canManageCourse, courseIdForClass } from "@/lib/permissions";

const schema = z.object({
  classId: z.string(),
  title: z.string().min(2),
  zoomLink: z.string().url(),
  zoomMeetingId: z.string().optional(),
  zoomPasscode: z.string().optional(),
  scheduledAt: z.string(),
  durationMin: z.number().default(60),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || !["SUPER_ADMIN", "TEACHER"].includes(user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const courseId = await courseIdForClass(body.data.classId);
  if (!courseId || !(await canManageCourse(user, courseId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const liveClass = await prisma.liveClass.upsert({
    where: { classId: body.data.classId },
    update: { ...body.data, scheduledAt: new Date(body.data.scheduledAt), teacherId: user.id },
    create: { ...body.data, scheduledAt: new Date(body.data.scheduledAt), teacherId: user.id },
  });
  return NextResponse.json({ liveClass }, { status: 201 });
}
