import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// Simple keyword tokenizer: splits "Fiqh March" into ["Fiqh", "March"] and
// matches each token against class title, module title, course title,
// teacher name, or date fields (month name / year).
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") ?? "").trim();
  const courseId = searchParams.get("courseId") ?? undefined;
  const teacherId = searchParams.get("teacherId") ?? undefined;

  const classes = await prisma.class.findMany({
    where: {
      module: { courseId: courseId || undefined },
      OR: q
        ? [
            { title: { contains: q } },
            { description: { contains: q } },
            { module: { title: { contains: q } } },
            { module: { course: { title: { contains: q } } } },
          ]
        : undefined,
    },
    include: {
      module: { include: { course: { select: { id: true, title: true, type: true } } } },
      video: { select: { teacherId: true } },
      liveClass: true,
    },
    orderBy: { date: "desc" },
    take: 50,
  });

  const filtered = teacherId
    ? classes.filter((c) => c.video?.teacherId === teacherId || c.liveClass?.teacherId === teacherId)
    : classes;

  return NextResponse.json({ results: filtered });
}
