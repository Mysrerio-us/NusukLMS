import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

export async function GET() {
  const user = await getCurrentUser();
  if (!user || user.role !== "TEACHER") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const links = await prisma.teacherCourse.findMany({
    where: { teacherId: user.id },
    include: { course: { select: { id: true, title: true, type: true } } },
  });
  return NextResponse.json({ courses: links.map((l) => l.course) });
}
