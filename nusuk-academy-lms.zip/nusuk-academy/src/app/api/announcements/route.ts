import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { canManageCourse } from "@/lib/permissions";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const courseId = searchParams.get("courseId") ?? undefined;
  const announcements = await prisma.announcement.findMany({
    where: { courseId: courseId || undefined },
    orderBy: { createdAt: "desc" },
    include: { author: { select: { fullName: true, username: true } }, course: { select: { title: true } } },
    take: 50,
  });
  return NextResponse.json({ announcements });
}

const schema = z.object({
  title: z.string().min(2),
  body: z.string().min(2),
  courseId: z.string().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || !["SUPER_ADMIN", "TEACHER"].includes(user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  if (body.data.courseId && !(await canManageCourse(user, body.data.courseId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const announcement = await prisma.announcement.create({
    data: { ...body.data, authorId: user.id },
  });

  if (body.data.courseId) {
    const enrolled = await prisma.enrollment.findMany({
      where: { courseId: body.data.courseId, status: "ACTIVE" },
      select: { studentId: true },
    });
    if (enrolled.length) {
      await prisma.notification.createMany({
        data: enrolled.map((e) => ({
          userId: e.studentId,
          type: "ANNOUNCEMENT" as const,
          title: announcement.title,
          body: announcement.body.slice(0, 140),
        })),
      });
    }
  }

  return NextResponse.json({ announcement }, { status: 201 });
}
