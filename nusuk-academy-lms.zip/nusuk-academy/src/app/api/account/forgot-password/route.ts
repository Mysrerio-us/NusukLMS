import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { prisma } from "@/lib/prisma";

// NOTE: Email sending is stubbed. Wire up Resend (see .env.example RESEND_API_KEY)
// or any SMTP provider in production. For local/dev, the reset link is logged
// to the server console and returned in the API response for convenience.
export async function POST(req: Request) {
  const { username } = await req.json();
  if (!username) return NextResponse.json({ error: "Username is required" }, { status: 400 });

  const user = await prisma.user.findUnique({ where: { username: username.trim().toLowerCase() } });

  // Always return success to avoid leaking which usernames exist
  if (!user) return NextResponse.json({ success: true });

  const token = nanoid(48);
  await prisma.passwordResetToken.create({
    data: { token, userId: user.id, expiresAt: new Date(Date.now() + 1000 * 60 * 60) }, // 1 hour
  });

  const resetUrl = `${process.env.NEXTAUTH_URL}/reset-password?token=${token}`;
  console.log(`[Password Reset] ${user.username}: ${resetUrl}`);

  // TODO (production): send via Resend/SMTP instead of returning it directly.
  return NextResponse.json({
    success: true,
    devResetUrl: process.env.NODE_ENV !== "production" ? resetUrl : undefined,
  });
}
