import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

const schema = z.object({
  fullName: z.string().min(2),
  gender: z.enum(["MALE", "FEMALE"]),
  dateOfBirth: z.string().min(1),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().min(5),
  address: z.string().min(3),
  courseId: z.string().min(1),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== "STUDENT") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = schema.safeParse(await req.json());
  if (!body.success) {
    return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });
  }
  const { fullName, gender, dateOfBirth, email, phone, address, courseId } = body.data;

  // Enforce gender <-> course-type rule (Male -> Alim, Female -> Alima)
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) return NextResponse.json({ error: "Course not found" }, { status: 404 });

  const expectedType = gender === "MALE" ? "ALIM" : "ALIMA";
  if (course.type !== expectedType) {
    return NextResponse.json(
      {
        error: `${gender === "MALE" ? "Male" : "Female"} students may only enroll in the ${
          expectedType === "ALIM" ? "Alim" : "Alima"
        } course.`,
      },
      { status: 400 }
    );
  }

  await prisma.$transaction([
    prisma.user.update({
      where: { id: user.id },
      data: {
        fullName,
        gender,
        dateOfBirth: new Date(dateOfBirth),
        email: email || undefined,
        phone,
        address,
        profileCompleted: true,
      },
    }),
    prisma.enrollment.upsert({
      where: { studentId_courseId: { studentId: user.id, courseId } },
      update: {},
      create: { studentId: user.id, courseId, status: "PENDING" },
    }),
  ]);

  return NextResponse.json({ success: true });
}
