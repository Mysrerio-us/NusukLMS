import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { canManageCourse, courseIdForModule } from "@/lib/permissions";

const schema = z.object({
  moduleId: z.string(),
  title: z.string().min(2),
  description: z.string().optional(),
  date: z.string().optional(),
  order: z.number().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || !["SUPER_ADMIN", "TEACHER"].includes(user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const courseId = await courseIdForModule(body.data.moduleId);
  if (!courseId || !(await canManageCourse(user, courseId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const cls = await prisma.class.create({
    data: {
      moduleId: body.data.moduleId,
      title: body.data.title,
      description: body.data.description,
      order: body.data.order ?? 0,
      date: body.data.date ? new Date(body.data.date) : undefined,
    },
  });

  // Notify enrolled students in this course
  const enrolled = await prisma.enrollment.findMany({
    where: { courseId, status: "ACTIVE" },
    select: { studentId: true },
  });
  if (enrolled.length) {
    await prisma.notification.createMany({
      data: enrolled.map((e) => ({
        userId: e.studentId,
        type: "NEW_CLASS" as const,
        title: "New class added",
        body: cls.title,
        link: `/student/courses/${courseId}`,
      })),
    });
  }

  return NextResponse.json({ class: cls }, { status: 201 });
}
