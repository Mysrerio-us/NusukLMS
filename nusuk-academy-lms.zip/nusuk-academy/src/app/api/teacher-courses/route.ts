import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

const schema = z.object({ teacherId: z.string(), courseId: z.string() });

export async function POST(req: Request) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const link = await prisma.teacherCourse.upsert({
    where: { teacherId_courseId: body.data },
    update: {},
    create: body.data,
  });
  return NextResponse.json({ link }, { status: 201 });
}

export async function DELETE(req: Request) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  await prisma.teacherCourse.delete({ where: { teacherId_courseId: body.data } });
  return NextResponse.json({ success: true });
}
