import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

const schema = z.object({
  status: z.enum(["APPROVED", "REJECTED"]),
  notes: z.string().optional(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const payment = await prisma.payment.update({
    where: { id: params.id },
    data: {
      status: body.data.status,
      notes: body.data.notes,
      reviewedById: admin.id,
      reviewedAt: new Date(),
    },
  });

  if (body.data.status === "APPROVED") {
    await prisma.enrollment.upsert({
      where: { studentId_courseId: { studentId: payment.studentId, courseId: payment.courseId } },
      update: { status: "ACTIVE" },
      create: { studentId: payment.studentId, courseId: payment.courseId, status: "ACTIVE" },
    });
  }

  await prisma.notification.create({
    data: {
      userId: payment.studentId,
      type: "PAYMENT_UPDATE",
      title: body.data.status === "APPROVED" ? "Payment approved" : "Payment rejected",
      body: body.data.notes,
    },
  });

  return NextResponse.json({ payment });
}
