import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status") ?? undefined;

  const payments = await prisma.payment.findMany({
    where: {
      studentId: user.role === "STUDENT" ? user.id : undefined,
      status: (status as any) || undefined,
    },
    orderBy: { createdAt: "desc" },
    include: {
      student: { select: { fullName: true, username: true } },
    },
  });
  return NextResponse.json({ payments });
}

// Student submits proof of a bank transfer for course fees.
// Real card payments (Stripe) can be added via a separate
// /api/payments/stripe-webhook route — see PAYMENTS.md.
const schema = z.object({
  courseId: z.string(),
  amount: z.number().positive(),
  currency: z.string().default("USD"),
  method: z.enum(["BANK_TRANSFER", "STRIPE", "MANUAL"]).default("BANK_TRANSFER"),
  proofUrl: z.string().url().optional(),
  reference: z.string().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== "STUDENT") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const payment = await prisma.payment.create({
    data: {
      ...body.data,
      studentId: user.id,
      status: body.data.proofUrl ? "SUBMITTED" : "PENDING",
    },
  });

  return NextResponse.json({ payment }, { status: 201 });
}
