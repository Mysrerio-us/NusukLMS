import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

const schema = z.object({
  studentId: z.string(),
  courseId: z.string(),
  status: z.enum(["PENDING", "ACTIVE", "SUSPENDED", "COMPLETED"]).default("PENDING"),
});

export async function POST(req: Request) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const student = await prisma.user.findUnique({ where: { id: body.data.studentId } });
  const course = await prisma.course.findUnique({ where: { id: body.data.courseId } });
  if (!student || !course) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const expectedType = student.gender === "MALE" ? "ALIM" : "ALIMA";
  if (student.gender && course.type !== expectedType) {
    return NextResponse.json(
      { error: `${student.gender === "MALE" ? "Male" : "Female"} students can only enroll in ${expectedType}.` },
      { status: 400 }
    );
  }

  const enrollment = await prisma.enrollment.upsert({
    where: { studentId_courseId: { studentId: body.data.studentId, courseId: body.data.courseId } },
    update: { status: body.data.status },
    create: body.data,
  });
  return NextResponse.json({ enrollment }, { status: 201 });
}
