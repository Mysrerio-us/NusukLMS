import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { nanoid } from "nanoid";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const { searchParams } = new URL(req.url);
  const role = searchParams.get("role") ?? undefined;
  const gender = searchParams.get("gender") ?? undefined;
  const courseId = searchParams.get("courseId") ?? undefined;
  const status = searchParams.get("status") ?? undefined;

  const users = await prisma.user.findMany({
    where: {
      role: (role as any) || undefined,
      gender: (gender as any) || undefined,
      enrollments: courseId || status ? {
        some: {
          courseId: courseId || undefined,
          status: (status as any) || undefined,
        },
      } : undefined,
    },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, username: true, email: true, role: true, fullName: true, gender: true,
      isActive: true, profileCompleted: true, createdAt: true,
      enrollments: { include: { course: { select: { title: true, type: true } } } },
    },
  });
  return NextResponse.json({ users });
}

const schema = z.object({
  role: z.enum(["TEACHER", "STUDENT"]),
  fullName: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
});

function generateUsername(role: string) {
  const prefix = role === "TEACHER" ? "teacher" : "student";
  return `${prefix}-${nanoid(6).toLowerCase()}`;
}

function generateTempPassword() {
  return nanoid(10);
}

export async function POST(req: Request) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const body = schema.safeParse(await req.json());
  if (!body.success) return NextResponse.json({ error: body.error.issues[0].message }, { status: 400 });

  const username = generateUsername(body.data.role);
  const tempPassword = generateTempPassword();
  const passwordHash = await bcrypt.hash(tempPassword, 12);

  const newUser = await prisma.user.create({
    data: {
      username,
      email: body.data.email || undefined,
      fullName: body.data.fullName,
      role: body.data.role,
      passwordHash,
      mustChangePassword: true,
      profileCompleted: body.data.role === "TEACHER", // teachers skip forced onboarding form
    },
  });

  await prisma.auditLog.create({
    data: { userId: admin.id, action: "CREATE_USER", entity: "User", entityId: newUser.id },
  });

  // Return the temporary credentials ONCE — admin must share them securely with the user.
  return NextResponse.json(
    { user: newUser, credentials: { username, tempPassword } },
    { status: 201 }
  );
}
