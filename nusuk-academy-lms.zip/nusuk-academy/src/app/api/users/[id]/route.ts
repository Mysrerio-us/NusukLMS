import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  const data = await req.json();
  const updated = await prisma.user.update({
    where: { id: params.id },
    data: {
      fullName: data.fullName,
      email: data.email,
      phone: data.phone,
      address: data.address,
      isActive: data.isActive,
      bio: data.bio,
    },
  });
  await prisma.auditLog.create({
    data: { userId: admin.id, action: "UPDATE_USER", entity: "User", entityId: params.id },
  });
  return NextResponse.json({ user: updated });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
  await prisma.user.delete({ where: { id: params.id } });
  await prisma.auditLog.create({
    data: { userId: admin.id, action: "DELETE_USER", entity: "User", entityId: params.id },
  });
  return NextResponse.json({ success: true });
}
