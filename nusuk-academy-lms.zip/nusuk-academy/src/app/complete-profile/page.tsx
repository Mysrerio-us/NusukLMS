"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Course = { id: string; title: string; type: "ALIM" | "ALIMA" };

export default function CompleteProfilePage() {
  const router = useRouter();
  const [courses, setCourses] = useState<Course[]>([]);
  const [form, setForm] = useState({
    fullName: "", gender: "", dateOfBirth: "", email: "", phone: "", address: "", courseId: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch("/api/courses").then((r) => r.json()).then((data) => setCourses(data.courses ?? []));
  }, []);

  const visibleCourses = courses.filter((c) =>
    !form.gender ? true : c.type === (form.gender === "MALE" ? "ALIM" : "ALIMA")
  );

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const res = await fetch("/api/account/complete-profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json();
      setError(data.error ?? "Something went wrong.");
      return;
    }
    router.push("/student");
    router.refresh();
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-sand-50 px-6 py-12">
      <div className="w-full max-w-lg">
        <div className="mb-8 text-center">
          <h1 className="font-display text-2xl text-ink-900">Complete your profile</h1>
          <p className="mt-2 text-sm text-ink-400">
            Just a few details so your teachers and administrators know who you are.
          </p>
        </div>
        <form onSubmit={handleSubmit} className="card space-y-4 p-6">
          {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
          <div>
            <label className="label">Full name</label>
            <input className="input" required value={form.fullName}
              onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Gender</label>
              <select className="input" required value={form.gender}
                onChange={(e) => setForm({ ...form, gender: e.target.value, courseId: "" })}>
                <option value="">Select…</option>
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
              </select>
            </div>
            <div>
              <label className="label">Date of birth</label>
              <input type="date" className="input" required value={form.dateOfBirth}
                onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" className="input" value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <label className="label">Phone</label>
            <input className="input" required value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div>
            <label className="label">Address</label>
            <input className="input" required value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </div>
          <div>
            <label className="label">Course</label>
            <select className="input" required value={form.courseId} disabled={!form.gender}
              onChange={(e) => setForm({ ...form, courseId: e.target.value })}>
              <option value="">
                {form.gender ? "Select your course…" : "Select gender first"}
              </option>
              {visibleCourses.map((c) => (
                <option key={c.id} value={c.id}>{c.title}</option>
              ))}
            </select>
            <p className="mt-1 text-xs text-ink-400">
              Male students are enrolled in Alim; female students are enrolled in Alima.
            </p>
          </div>
          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? "Saving…" : "Save and continue"}
          </button>
        </form>
      </div>
    </main>
  );
}
