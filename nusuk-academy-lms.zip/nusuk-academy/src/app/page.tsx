import Link from "next/link";
import { getCurrentUser } from "@/lib/session";
import { redirect } from "next/navigation";

export default async function HomePage() {
  const user = await getCurrentUser();

  if (user) {
    if (user.mustChangePassword) redirect("/change-password");
    if (user.role === "STUDENT" && !user.profileCompleted) redirect("/complete-profile");
    if (user.role === "SUPER_ADMIN") redirect("/admin");
    if (user.role === "TEACHER") redirect("/teacher");
    if (user.role === "STUDENT") redirect("/student");
  }

  return (
    <main className="min-h-screen bg-sand-50">
      <div className="geo-divider" />
      <section className="mx-auto max-w-5xl px-6 py-24 text-center">
        <p className="mb-3 text-sm font-medium uppercase tracking-widest text-emerald-700">
          Nusuk Academy
        </p>
        <h1 className="font-display text-4xl leading-tight text-ink-900 sm:text-5xl">
          Structured Alim &amp; Alima courses,
          <br className="hidden sm:block" /> taught with care.
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-ink-400">
          Live Zoom classes, recorded lectures, downloadable resources, and clear
          progress tracking — all in one calm, focused learning space.
        </p>
        <div className="mt-10 flex justify-center gap-4">
          <Link href="/login" className="btn-primary px-6 py-3">
            Student &amp; Teacher Login
          </Link>
        </div>
      </section>
      <div className="geo-divider" />
      <footer className="py-8 text-center text-xs text-ink-400">
        Accounts are created by Nusuk Academy administrators. Contact your admin for access.
      </footer>
    </main>
  );
}
