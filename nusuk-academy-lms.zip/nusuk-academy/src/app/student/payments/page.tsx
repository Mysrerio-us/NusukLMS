"use client";

import { useEffect, useState } from "react";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/student", label: "My Courses" },
  { href: "/student/payments", label: "Payments" },
  { href: "/student/profile", label: "Profile" },
];

type Settings = {
  bankName?: string; accountName?: string; accountNumber?: string;
  iban?: string; swiftCode?: string; instructions?: string;
};
type Payment = { id: string; amount: number; currency: string; status: string; createdAt: string };

export default function StudentPaymentsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [courseId, setCourseId] = useState("");
  const [amount, setAmount] = useState("");
  const [reference, setReference] = useState("");
  const [proofUrl, setProofUrl] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    const [sRes, pRes] = await Promise.all([
      fetch("/api/payment-settings"),
      fetch("/api/payments"),
    ]);
    const sData = await sRes.json();
    const pData = await pRes.json();
    setSettings(sData.settings);
    setPayments(pData.payments ?? []);
  }
  useEffect(() => { load(); }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMessage("");
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ courseId, amount: Number(amount), reference, proofUrl: proofUrl || undefined }),
    });
    if (res.ok) {
      setMessage("Payment submitted — an administrator will review it shortly.");
      setAmount(""); setReference(""); setProofUrl(""); setCourseId("");
      load();
    } else {
      setMessage("Something went wrong submitting your payment.");
    }
  }

  return (
    <DashboardShell role="Student" userName="Student" navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">Payments</h1>

      {settings && (
        <div className="card mt-6 p-5">
          <h2 className="font-medium text-ink-900">Bank transfer details</h2>
          <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
            {settings.bankName && <div><dt className="text-ink-400">Bank</dt><dd>{settings.bankName}</dd></div>}
            {settings.accountName && <div><dt className="text-ink-400">Account name</dt><dd>{settings.accountName}</dd></div>}
            {settings.accountNumber && <div><dt className="text-ink-400">Account number</dt><dd>{settings.accountNumber}</dd></div>}
            {settings.iban && <div><dt className="text-ink-400">IBAN</dt><dd>{settings.iban}</dd></div>}
            {settings.swiftCode && <div><dt className="text-ink-400">SWIFT</dt><dd>{settings.swiftCode}</dd></div>}
          </dl>
          {settings.instructions && <p className="mt-3 text-sm text-ink-700">{settings.instructions}</p>}
        </div>
      )}

      <form onSubmit={submit} className="card mt-6 space-y-3 p-5">
        <h2 className="font-medium text-ink-900">Submit payment proof</h2>
        {message && <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-800">{message}</p>}
        <input className="input" placeholder="Course ID (from your course URL)" required
          value={courseId} onChange={(e) => setCourseId(e.target.value)} />
        <input className="input" type="number" placeholder="Amount paid" required
          value={amount} onChange={(e) => setAmount(e.target.value)} />
        <input className="input" placeholder="Bank transfer reference (optional)"
          value={reference} onChange={(e) => setReference(e.target.value)} />
        <input className="input" placeholder="Link to proof/screenshot (upload to Drive/Imgur first)"
          value={proofUrl} onChange={(e) => setProofUrl(e.target.value)} />
        <button type="submit" className="btn-primary">Submit for review</button>
      </form>

      <div className="mt-6 space-y-2">
        {payments.map((p) => (
          <div key={p.id} className="card flex items-center justify-between p-4 text-sm">
            <span>{p.currency} {p.amount.toFixed(2)} · {new Date(p.createdAt).toLocaleDateString()}</span>
            <span className="font-medium">{p.status}</span>
          </div>
        ))}
      </div>
    </DashboardShell>
  );
}
