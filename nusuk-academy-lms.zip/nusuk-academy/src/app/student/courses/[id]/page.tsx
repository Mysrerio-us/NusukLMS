import { requireUser } from "@/lib/session";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import DashboardShell from "@/components/DashboardShell";
import ClassProgressToggle from "@/components/ClassProgressToggle";

const NAV = [
  { href: "/student", label: "My Courses" },
  { href: "/student/payments", label: "Payments" },
  { href: "/student/profile", label: "Profile" },
];

export default async function StudentCoursePage({ params }: { params: { id: string } }) {
  const user = await requireUser(["STUDENT"]);

  const enrollment = await prisma.enrollment.findUnique({
    where: { studentId_courseId: { studentId: user.id, courseId: params.id } },
  });
  if (!enrollment || enrollment.status !== "ACTIVE") redirect("/student");

  const course = await prisma.course.findUnique({
    where: { id: params.id },
    include: {
      modules: {
        orderBy: { order: "asc" },
        include: {
          classes: {
            orderBy: { order: "asc" },
            include: { video: true, liveClass: true, resources: true },
          },
        },
      },
      announcements: { orderBy: { createdAt: "desc" }, take: 5 },
    },
  });
  if (!course) redirect("/student");

  const progress = await prisma.classProgress.findMany({
    where: { studentId: user.id },
    select: { classId: true, completed: true },
  });
  const progressMap = new Map(progress.map((p) => [p.classId, p.completed]));

  return (
    <DashboardShell role="Student" userName={user.name ?? user.username} navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">{course.title}</h1>

      {course.announcements.length > 0 && (
        <div className="mt-6 space-y-2">
          {course.announcements.map((a) => (
            <div key={a.id} className="rounded-lg bg-emerald-50 px-4 py-3 text-sm text-emerald-900">
              <span className="font-medium">{a.title}:</span> {a.body}
            </div>
          ))}
        </div>
      )}

      <div className="mt-8 space-y-6">
        {course.modules.map((m) => (
          <div key={m.id} className="card p-5">
            <h2 className="font-medium text-ink-900">{m.title}</h2>
            <ul className="mt-4 space-y-4">
              {m.classes.map((c) => (
                <li key={c.id} className="rounded-lg border border-sand-200 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-medium text-ink-800">{c.title}</p>
                    <ClassProgressToggle classId={c.id} initialCompleted={progressMap.get(c.id) ?? false} />
                  </div>
                  {c.description && <p className="mt-1 text-sm text-ink-400">{c.description}</p>}

                  {c.liveClass && (
                    <div className="mt-3 rounded-lg bg-sand-100 p-3 text-sm">
                      <p className="font-medium">{c.liveClass.title}</p>
                      <p className="text-ink-400">
                        {new Date(c.liveClass.scheduledAt).toLocaleString()}
                      </p>
                      <a href={c.liveClass.zoomLink} target="_blank" className="btn-primary mt-2 inline-flex py-1.5">
                        Join Live Class
                      </a>
                    </div>
                  )}

                  {c.video && (
                    <div className="mt-3">
                      <div className="aspect-video overflow-hidden rounded-lg bg-black">
                        <iframe src={c.video.videoUrl} className="h-full w-full" allowFullScreen title={c.title} />
                      </div>
                      {c.video.allowDownload && c.video.downloadUrl && (
                        <a href={c.video.downloadUrl} className="mt-2 inline-block text-sm text-emerald-700 hover:underline">
                          Download video
                        </a>
                      )}
                    </div>
                  )}

                  {c.resources.length > 0 && (
                    <ul className="mt-3 space-y-1">
                      {c.resources.map((r) => (
                        <li key={r.id}>
                          <a href={r.fileUrl} target="_blank" className="text-sm text-emerald-700 hover:underline">
                            📎 {r.title}
                          </a>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              ))}
              {m.classes.length === 0 && <p className="text-sm text-ink-400">No classes yet.</p>}
            </ul>
          </div>
        ))}
      </div>
    </DashboardShell>
  );
}
