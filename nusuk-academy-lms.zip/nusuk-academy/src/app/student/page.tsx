import Link from "next/link";
import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/student", label: "My Courses" },
  { href: "/student/payments", label: "Payments" },
  { href: "/student/profile", label: "Profile" },
];

export default async function StudentDashboard() {
  const user = await requireUser(["STUDENT"]);

  const enrollments = await prisma.enrollment.findMany({
    where: { studentId: user.id },
    include: {
      course: {
        include: { modules: { include: { classes: { select: { id: true } } } } },
      },
    },
  });

  const progressByClass = await prisma.classProgress.findMany({
    where: { studentId: user.id, completed: true },
    select: { classId: true },
  });
  const completedSet = new Set(progressByClass.map((p) => p.classId));

  return (
    <DashboardShell role="Student" userName={user.name ?? user.username} navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">My Courses</h1>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {enrollments.map((e) => {
          const allClasses = e.course.modules.flatMap((m) => m.classes);
          const completed = allClasses.filter((c) => completedSet.has(c.id)).length;
          const pct = allClasses.length ? Math.round((completed / allClasses.length) * 100) : 0;

          return (
            <div key={e.id} className="card p-5">
              <div className="flex items-center justify-between">
                <p className="font-medium text-ink-900">{e.course.title}</p>
                <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                  e.status === "ACTIVE" ? "bg-emerald-100 text-emerald-800" : "bg-sand-200 text-sand-800"
                }`}>{e.status}</span>
              </div>
              <div className="mt-4">
                <div className="h-2 w-full overflow-hidden rounded-full bg-sand-200">
                  <div className="h-full rounded-full bg-emerald-600" style={{ width: `${pct}%` }} />
                </div>
                <p className="mt-2 text-sm text-ink-400">
                  {pct}% complete · {completed}/{allClasses.length} classes
                </p>
              </div>
              {e.status === "ACTIVE" ? (
                <Link href={`/student/courses/${e.course.id}`} className="btn-primary mt-4 w-full">
                  Open course
                </Link>
              ) : (
                <p className="mt-4 text-sm text-ink-400">
                  Your enrollment is pending payment approval. Visit the Payments tab to submit your fee.
                </p>
              )}
            </div>
          );
        })}
        {enrollments.length === 0 && (
          <p className="text-sm text-ink-400">You are not enrolled in any course yet.</p>
        )}
      </div>
    </DashboardShell>
  );
}
