import Link from "next/link";
import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/student", label: "My Courses" },
  { href: "/student/payments", label: "Payments" },
  { href: "/student/profile", label: "Profile" },
];

export default async function StudentProfilePage() {
  const user = await requireUser(["STUDENT"]);
  const dbUser = await prisma.user.findUnique({ where: { id: user.id } });

  return (
    <DashboardShell role="Student" userName={user.name ?? user.username} navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">My Profile</h1>
      <div className="card mt-6 max-w-md space-y-3 p-6 text-sm">
        <div><span className="text-ink-400">Full name:</span> {dbUser?.fullName}</div>
        <div><span className="text-ink-400">Username:</span> {dbUser?.username}</div>
        <div><span className="text-ink-400">Email:</span> {dbUser?.email ?? "—"}</div>
        <div><span className="text-ink-400">Phone:</span> {dbUser?.phone}</div>
        <div><span className="text-ink-400">Gender:</span> {dbUser?.gender}</div>
        <div><span className="text-ink-400">Address:</span> {dbUser?.address}</div>
      </div>
      <Link href="/change-password" className="btn-secondary mt-4 inline-flex">Change password</Link>
    </DashboardShell>
  );
}
