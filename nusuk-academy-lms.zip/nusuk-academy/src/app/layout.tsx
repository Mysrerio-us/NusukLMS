import type { Metadata } from "next";
import "./globals.css";
import Providers from "@/components/Providers";

export const metadata: Metadata = {
  title: "Nusuk Academy — Alim & Alima Online Courses",
  description:
    "Nusuk Academy is an online Islamic education platform offering structured Alim and Alima courses with live classes, recorded lectures, and progress tracking.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
