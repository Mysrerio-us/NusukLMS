"use client";

import { useEffect, useState } from "react";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/courses", label: "Courses" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/settings", label: "Payment Settings" },
];

type UserRow = {
  id: string; username: string; fullName: string | null; role: string;
  gender: string | null; isActive: boolean; profileCompleted: boolean;
  enrollments: { status: string; course: { title: string; type: string } }[];
};

export default function AdminUsersPage() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [roleFilter, setRoleFilter] = useState("");
  const [genderFilter, setGenderFilter] = useState("");
  const [createRole, setCreateRole] = useState<"STUDENT" | "TEACHER">("STUDENT");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [credentials, setCredentials] = useState<{ username: string; tempPassword: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    const params = new URLSearchParams();
    if (roleFilter) params.set("role", roleFilter);
    if (genderFilter) params.set("gender", genderFilter);
    const res = await fetch(`/api/users?${params.toString()}`);
    const data = await res.json();
    setUsers(data.users ?? []);
  }

  useEffect(() => { load(); }, [roleFilter, genderFilter]);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const res = await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role: createRole, fullName, email }),
    });
    setLoading(false);
    const data = await res.json();
    if (!res.ok) { setError(data.error ?? "Failed to create user"); return; }
    setCredentials(data.credentials);
    setFullName(""); setEmail("");
    load();
  }

  async function toggleActive(id: string, isActive: boolean) {
    await fetch(`/api/users/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !isActive }),
    });
    load();
  }

  async function removeUser(id: string) {
    if (!confirm("Delete this user permanently?")) return;
    await fetch(`/api/users/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <DashboardShell role="Super Admin" userName="Admin" navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">Users</h1>

      <div className="mt-6 card p-5">
        <h2 className="font-medium text-ink-900">Create a new account</h2>
        <form onSubmit={handleCreate} className="mt-4 grid gap-4 sm:grid-cols-4">
          <select className="input" value={createRole} onChange={(e) => setCreateRole(e.target.value as any)}>
            <option value="STUDENT">Student</option>
            <option value="TEACHER">Teacher</option>
          </select>
          <input className="input" placeholder="Full name (optional)" value={fullName}
            onChange={(e) => setFullName(e.target.value)} />
          <input className="input" placeholder="Email (optional)" value={email}
            onChange={(e) => setEmail(e.target.value)} />
          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? "Creating…" : "Create account"}
          </button>
        </form>
        {error && <p className="mt-3 text-sm text-red-700">{error}</p>}
        {credentials && (
          <div className="mt-4 rounded-lg bg-emerald-50 p-4 text-sm text-emerald-900">
            <p className="font-medium">Account created — share these credentials securely (shown once):</p>
            <p className="mt-1">Username: <span className="font-mono">{credentials.username}</span></p>
            <p>Temporary password: <span className="font-mono">{credentials.tempPassword}</span></p>
          </div>
        )}
      </div>

      <div className="mt-8 flex flex-wrap gap-3">
        <select className="input w-auto" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
          <option value="">All roles</option>
          <option value="STUDENT">Students</option>
          <option value="TEACHER">Teachers</option>
        </select>
        <select className="input w-auto" value={genderFilter} onChange={(e) => setGenderFilter(e.target.value)}>
          <option value="">All genders</option>
          <option value="MALE">Male</option>
          <option value="FEMALE">Female</option>
        </select>
      </div>

      <div className="mt-4 overflow-x-auto card">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-sand-200 text-ink-400">
            <tr>
              <th className="px-4 py-3">Username</th>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Gender</th>
              <th className="px-4 py-3">Course</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b border-sand-100 last:border-0">
                <td className="px-4 py-3 font-mono">{u.username}</td>
                <td className="px-4 py-3">{u.fullName ?? "—"}</td>
                <td className="px-4 py-3">{u.role}</td>
                <td className="px-4 py-3">{u.gender ?? "—"}</td>
                <td className="px-4 py-3">{u.enrollments[0]?.course.title ?? "—"}</td>
                <td className="px-4 py-3">
                  <span className={u.isActive ? "text-emerald-700" : "text-red-600"}>
                    {u.isActive ? "Active" : "Disabled"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <button className="mr-3 text-emerald-700 hover:underline" onClick={() => toggleActive(u.id, u.isActive)}>
                    {u.isActive ? "Disable" : "Enable"}
                  </button>
                  <button className="text-red-600 hover:underline" onClick={() => removeUser(u.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {users.length === 0 && (
              <tr><td colSpan={7} className="px-4 py-8 text-center text-ink-400">No users found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </DashboardShell>
  );
}
