"use client";

import { useEffect, useState } from "react";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/courses", label: "Courses" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/settings", label: "Payment Settings" },
];

export default function AdminSettingsPage() {
  const [form, setForm] = useState({
    bankName: "", accountName: "", accountNumber: "", iban: "", swiftCode: "", instructions: "",
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/payment-settings").then((r) => r.json()).then((d) => {
      if (d.settings) setForm({ ...form, ...d.settings });
    });
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/payment-settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <DashboardShell role="Super Admin" userName="Admin" navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">Payment Settings</h1>
      <p className="mt-1 text-sm text-ink-400">
        These bank details are shown to students when paying course fees by transfer.
      </p>
      <form onSubmit={save} className="card mt-6 grid gap-4 p-6 sm:grid-cols-2">
        {saved && <p className="sm:col-span-2 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-800">Saved.</p>}
        <div><label className="label">Bank name</label>
          <input className="input" value={form.bankName} onChange={(e) => setForm({ ...form, bankName: e.target.value })} /></div>
        <div><label className="label">Account name</label>
          <input className="input" value={form.accountName} onChange={(e) => setForm({ ...form, accountName: e.target.value })} /></div>
        <div><label className="label">Account number</label>
          <input className="input" value={form.accountNumber} onChange={(e) => setForm({ ...form, accountNumber: e.target.value })} /></div>
        <div><label className="label">IBAN</label>
          <input className="input" value={form.iban} onChange={(e) => setForm({ ...form, iban: e.target.value })} /></div>
        <div><label className="label">SWIFT code</label>
          <input className="input" value={form.swiftCode} onChange={(e) => setForm({ ...form, swiftCode: e.target.value })} /></div>
        <div className="sm:col-span-2"><label className="label">Instructions for students</label>
          <textarea className="input" rows={4} value={form.instructions} onChange={(e) => setForm({ ...form, instructions: e.target.value })} /></div>
        <button type="submit" className="btn-primary sm:col-span-2">Save settings</button>
      </form>
    </DashboardShell>
  );
}
