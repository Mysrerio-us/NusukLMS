import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/courses", label: "Courses" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/settings", label: "Payment Settings" },
];

export default async function AdminDashboard() {
  const user = await requireUser(["SUPER_ADMIN"]);

  const [totalStudents, maleStudents, femaleStudents, alimEnrollments, alimaEnrollments, teacherCount, payments] =
    await Promise.all([
      prisma.user.count({ where: { role: "STUDENT" } }),
      prisma.user.count({ where: { role: "STUDENT", gender: "MALE" } }),
      prisma.user.count({ where: { role: "STUDENT", gender: "FEMALE" } }),
      prisma.enrollment.count({ where: { course: { type: "ALIM" } } }),
      prisma.enrollment.count({ where: { course: { type: "ALIMA" } } }),
      prisma.user.count({ where: { role: "TEACHER" } }),
      prisma.payment.findMany({ where: { status: "APPROVED" } }),
    ]);

  const revenue = payments.reduce((sum, p) => sum + p.amount, 0);

  const stats = [
    { label: "Total students", value: totalStudents },
    { label: "Male students (Alim)", value: maleStudents },
    { label: "Female students (Alima)", value: femaleStudents },
    { label: "Alim enrollments", value: alimEnrollments },
    { label: "Alima enrollments", value: alimaEnrollments },
    { label: "Teachers", value: teacherCount },
    { label: "Approved revenue", value: `$${revenue.toFixed(2)}` },
  ];

  return (
    <DashboardShell role="Super Admin" userName={user.name ?? user.username} navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">Dashboard</h1>
      <p className="mt-1 text-sm text-ink-400">An overview of Nusuk Academy right now.</p>

      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="card p-5">
            <p className="text-2xl font-semibold text-ink-900">{s.value}</p>
            <p className="mt-1 text-sm text-ink-400">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        <a href="/admin/users" className="card p-5 hover:bg-sand-100">
          <p className="font-medium text-ink-900">Create a user</p>
          <p className="mt-1 text-sm text-ink-400">Add a student or teacher account.</p>
        </a>
        <a href="/admin/courses" className="card p-5 hover:bg-sand-100">
          <p className="font-medium text-ink-900">Manage courses</p>
          <p className="mt-1 text-sm text-ink-400">Alim &amp; Alima modules and classes.</p>
        </a>
        <a href="/admin/payments" className="card p-5 hover:bg-sand-100">
          <p className="font-medium text-ink-900">Review payments</p>
          <p className="mt-1 text-sm text-ink-400">Approve submitted fee payments.</p>
        </a>
      </div>
    </DashboardShell>
  );
}
