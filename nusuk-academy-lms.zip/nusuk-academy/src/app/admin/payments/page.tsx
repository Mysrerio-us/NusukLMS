"use client";

import { useEffect, useState } from "react";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/courses", label: "Courses" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/settings", label: "Payment Settings" },
];

type Payment = {
  id: string; amount: number; currency: string; status: string; proofUrl: string | null;
  reference: string | null; createdAt: string; student: { fullName: string | null; username: string };
};

export default function AdminPaymentsPage() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [filter, setFilter] = useState("SUBMITTED");

  async function load() {
    const params = filter ? `?status=${filter}` : "";
    const res = await fetch(`/api/payments${params}`);
    const data = await res.json();
    setPayments(data.payments ?? []);
  }
  useEffect(() => { load(); }, [filter]);

  async function review(id: string, status: "APPROVED" | "REJECTED") {
    const notes = status === "REJECTED" ? prompt("Reason for rejection (optional):") ?? "" : "";
    await fetch(`/api/payments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, notes }),
    });
    load();
  }

  return (
    <DashboardShell role="Super Admin" userName="Admin" navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">Payments</h1>

      <select className="input mt-4 w-auto" value={filter} onChange={(e) => setFilter(e.target.value)}>
        <option value="SUBMITTED">Awaiting review</option>
        <option value="APPROVED">Approved</option>
        <option value="REJECTED">Rejected</option>
        <option value="">All</option>
      </select>

      <div className="mt-4 space-y-3">
        {payments.map((p) => (
          <div key={p.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
            <div>
              <p className="font-medium text-ink-900">{p.student.fullName ?? p.student.username}</p>
              <p className="text-sm text-ink-400">
                {p.currency} {p.amount.toFixed(2)} · {new Date(p.createdAt).toLocaleDateString()}
                {p.reference && ` · ref: ${p.reference}`}
              </p>
              {p.proofUrl && (
                <a href={p.proofUrl} target="_blank" className="text-sm text-emerald-700 hover:underline">
                  View payment proof
                </a>
              )}
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs font-medium uppercase text-ink-400">{p.status}</span>
              {p.status === "SUBMITTED" && (
                <>
                  <button className="btn-primary py-1.5" onClick={() => review(p.id, "APPROVED")}>Approve</button>
                  <button className="btn-secondary py-1.5" onClick={() => review(p.id, "REJECTED")}>Reject</button>
                </>
              )}
            </div>
          </div>
        ))}
        {payments.length === 0 && <p className="text-sm text-ink-400">No payments in this filter.</p>}
      </div>
    </DashboardShell>
  );
}
