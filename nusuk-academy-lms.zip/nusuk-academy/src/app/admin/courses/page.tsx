"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/courses", label: "Courses" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/settings", label: "Payment Settings" },
];

type Course = { id: string; title: string; type: "ALIM" | "ALIMA"; feeAmount: number; currency: string; modules: { id: string }[] };

export default function AdminCoursesPage() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [title, setTitle] = useState("");
  const [type, setType] = useState<"ALIM" | "ALIMA">("ALIM");
  const [fee, setFee] = useState("0");
  const [loading, setLoading] = useState(false);

  async function load() {
    const res = await fetch("/api/courses");
    const data = await res.json();
    setCourses(data.courses ?? []);
  }
  useEffect(() => { load(); }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    await fetch("/api/courses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, type, feeAmount: Number(fee) }),
    });
    setLoading(false);
    setTitle(""); setFee("0");
    load();
  }

  return (
    <DashboardShell role="Super Admin" userName="Admin" navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">Courses</h1>

      <div className="mt-6 card p-5">
        <h2 className="font-medium text-ink-900">Create a course</h2>
        <form onSubmit={handleCreate} className="mt-4 grid gap-4 sm:grid-cols-4">
          <input className="input sm:col-span-2" placeholder="Course title (e.g. Alim Course 2026)"
            required value={title} onChange={(e) => setTitle(e.target.value)} />
          <select className="input" value={type} onChange={(e) => setType(e.target.value as any)}>
            <option value="ALIM">Alim (male)</option>
            <option value="ALIMA">Alima (female)</option>
          </select>
          <input className="input" type="number" min="0" step="0.01" placeholder="Fee"
            value={fee} onChange={(e) => setFee(e.target.value)} />
          <button type="submit" className="btn-primary sm:col-span-4" disabled={loading}>
            {loading ? "Creating…" : "Create course"}
          </button>
        </form>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {courses.map((c) => (
          <Link key={c.id} href={`/admin/courses/${c.id}`} className="card p-5 hover:bg-sand-100">
            <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
              c.type === "ALIM" ? "bg-emerald-100 text-emerald-800" : "bg-sand-200 text-sand-800"
            }`}>{c.type}</span>
            <p className="mt-3 font-medium text-ink-900">{c.title}</p>
            <p className="mt-1 text-sm text-ink-400">{c.modules.length} modules · {c.currency} {c.feeAmount}</p>
          </Link>
        ))}
        {courses.length === 0 && <p className="text-sm text-ink-400">No courses yet — create one above.</p>}
      </div>
    </DashboardShell>
  );
}
