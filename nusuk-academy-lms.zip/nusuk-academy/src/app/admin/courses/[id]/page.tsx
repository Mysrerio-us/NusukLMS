import { requireUser } from "@/lib/session";
import DashboardShell from "@/components/DashboardShell";
import CourseManager from "@/components/CourseManager";
import TeacherAssign from "@/components/TeacherAssign";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/courses", label: "Courses" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/settings", label: "Payment Settings" },
];

export default async function AdminCourseDetailPage({ params }: { params: { id: string } }) {
  const user = await requireUser(["SUPER_ADMIN"]);
  return (
    <DashboardShell role="Super Admin" userName={user.name ?? user.username} navItems={NAV}>
      <div className="mb-6">
        <TeacherAssign courseId={params.id} />
      </div>
      <CourseManager courseId={params.id} />
    </DashboardShell>
  );
}
