import Link from "next/link";
import { requireUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/teacher", label: "My Courses" },
  { href: "/teacher/announcements", label: "Announcements" },
];

export default async function TeacherDashboard() {
  const user = await requireUser(["TEACHER"]);

  const links = await prisma.teacherCourse.findMany({
    where: { teacherId: user.id },
    include: {
      course: {
        include: { modules: { select: { id: true } }, _count: { select: { enrollments: true } } },
      },
    },
  });

  return (
    <DashboardShell role="Teacher" userName={user.name ?? user.username} navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">My Courses</h1>
      <p className="mt-1 text-sm text-ink-400">Courses assigned to you by an administrator.</p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {links.map(({ course }) => (
          <Link key={course.id} href={`/teacher/courses/${course.id}`} className="card p-5 hover:bg-sand-100">
            <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
              course.type === "ALIM" ? "bg-emerald-100 text-emerald-800" : "bg-sand-200 text-sand-800"
            }`}>{course.type}</span>
            <p className="mt-3 font-medium text-ink-900">{course.title}</p>
            <p className="mt-1 text-sm text-ink-400">
              {course.modules.length} modules · {course._count.enrollments} students
            </p>
          </Link>
        ))}
        {links.length === 0 && (
          <p className="text-sm text-ink-400">No courses assigned yet — contact your administrator.</p>
        )}
      </div>
    </DashboardShell>
  );
}
