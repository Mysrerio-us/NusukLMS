"use client";

import { useEffect, useState } from "react";
import DashboardShell from "@/components/DashboardShell";

const NAV = [
  { href: "/teacher", label: "My Courses" },
  { href: "/teacher/announcements", label: "Announcements" },
];

type Course = { id: string; title: string };
type Announcement = { id: string; title: string; body: string; createdAt: string; course: { title: string } | null };

export default function TeacherAnnouncementsPage() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [courseId, setCourseId] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  async function load() {
    const [uRes, aRes] = await Promise.all([
      fetch("/api/teacher/my-courses"),
      fetch("/api/announcements"),
    ]);
    const uData = await uRes.json();
    const aData = await aRes.json();
    setCourses(uData.courses ?? []);
    setAnnouncements(aData.announcements ?? []);
  }
  useEffect(() => { load(); }, []);

  async function post(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/announcements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, body, courseId: courseId || undefined }),
    });
    setTitle(""); setBody("");
    load();
  }

  return (
    <DashboardShell role="Teacher" userName="Teacher" navItems={NAV}>
      <h1 className="font-display text-2xl text-ink-900">Announcements</h1>

      <form onSubmit={post} className="card mt-6 space-y-3 p-5">
        <select className="input" value={courseId} onChange={(e) => setCourseId(e.target.value)}>
          <option value="">Select a course…</option>
          {courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
        </select>
        <input className="input" placeholder="Title" required value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea className="input" rows={3} placeholder="Message" required value={body} onChange={(e) => setBody(e.target.value)} />
        <button type="submit" className="btn-primary">Post announcement</button>
      </form>

      <div className="mt-6 space-y-3">
        {announcements.map((a) => (
          <div key={a.id} className="card p-4">
            <p className="font-medium text-ink-900">{a.title}</p>
            <p className="mt-1 text-sm text-ink-700">{a.body}</p>
            <p className="mt-2 text-xs text-ink-400">
              {a.course?.title ?? "All courses"} · {new Date(a.createdAt).toLocaleDateString()}
            </p>
          </div>
        ))}
      </div>
    </DashboardShell>
  );
}
