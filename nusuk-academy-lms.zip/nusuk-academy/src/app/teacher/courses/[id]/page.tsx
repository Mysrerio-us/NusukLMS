import { requireUser } from "@/lib/session";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import DashboardShell from "@/components/DashboardShell";
import CourseManager from "@/components/CourseManager";

const NAV = [
  { href: "/teacher", label: "My Courses" },
  { href: "/teacher/announcements", label: "Announcements" },
];

export default async function TeacherCourseDetailPage({ params }: { params: { id: string } }) {
  const user = await requireUser(["TEACHER"]);

  const link = await prisma.teacherCourse.findUnique({
    where: { teacherId_courseId: { teacherId: user.id, courseId: params.id } },
  });
  if (!link) redirect("/teacher");

  return (
    <DashboardShell role="Teacher" userName={user.name ?? user.username} navItems={NAV}>
      <CourseManager courseId={params.id} />
    </DashboardShell>
  );
}
