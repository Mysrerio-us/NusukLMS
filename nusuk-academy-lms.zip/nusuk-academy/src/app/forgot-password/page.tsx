"use client";

import { useState } from "react";

export default function ForgotPasswordPage() {
  const [username, setUsername] = useState("");
  const [message, setMessage] = useState("");
  const [devUrl, setDevUrl] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const res = await fetch("/api/account/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username }),
    });
    const data = await res.json();
    setLoading(false);
    setMessage("If that username exists, a reset link has been sent.");
    if (data.devResetUrl) setDevUrl(data.devResetUrl);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-sand-50 px-6">
      <div className="w-full max-w-sm">
        <h1 className="mb-6 text-center font-display text-2xl text-ink-900">Reset your password</h1>
        <form onSubmit={handleSubmit} className="card space-y-4 p-6">
          {message && <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-800">{message}</p>}
          {devUrl && (
            <p className="break-all rounded-lg bg-sand-100 px-3 py-2 text-xs text-ink-700">
              Dev mode link: <a className="text-emerald-700 underline" href={devUrl}>{devUrl}</a>
            </p>
          )}
          <div>
            <label className="label">Username</label>
            <input className="input" required value={username}
              onChange={(e) => setUsername(e.target.value)} />
          </div>
          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? "Sending…" : "Send reset link"}
          </button>
        </form>
      </div>
    </main>
  );
}
