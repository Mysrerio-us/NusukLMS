import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";

export type SessionUser = {
  id: string;
  username: string;
  role: "SUPER_ADMIN" | "TEACHER" | "STUDENT";
  mustChangePassword: boolean;
  profileCompleted: boolean;
  name?: string | null;
  email?: string | null;
};

export async function getCurrentUser(): Promise<SessionUser | null> {
  const session = await getServerSession(authOptions);
  if (!session?.user) return null;
  return session.user as unknown as SessionUser;
}

/** Redirects to /login if unauthenticated, or forces onboarding steps first. */
export async function requireUser(allowedRoles?: SessionUser["role"][]) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.mustChangePassword) redirect("/change-password");
  if (!user.profileCompleted && user.role === "STUDENT") redirect("/complete-profile");
  if (allowedRoles && !allowedRoles.includes(user.role)) redirect("/");
  return user;
}
