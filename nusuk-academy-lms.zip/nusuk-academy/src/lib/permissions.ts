import { prisma } from "@/lib/prisma";
import type { SessionUser } from "@/lib/session";

/** Super admins can manage any course; teachers only courses assigned to them. */
export async function canManageCourse(user: SessionUser, courseId: string): Promise<boolean> {
  if (user.role === "SUPER_ADMIN") return true;
  if (user.role !== "TEACHER") return false;
  const link = await prisma.teacherCourse.findUnique({
    where: { teacherId_courseId: { teacherId: user.id, courseId } },
  });
  return !!link;
}

/** Resolve the courseId that owns a module/class, for permission checks. */
export async function courseIdForModule(moduleId: string) {
  const m = await prisma.module.findUnique({ where: { id: moduleId }, select: { courseId: true } });
  return m?.courseId ?? null;
}

export async function courseIdForClass(classId: string) {
  const c = await prisma.class.findUnique({
    where: { id: classId },
    select: { module: { select: { courseId: true } } },
  });
  return c?.module.courseId ?? null;
}
