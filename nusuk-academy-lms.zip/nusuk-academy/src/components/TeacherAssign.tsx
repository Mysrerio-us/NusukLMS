"use client";

import { useEffect, useState } from "react";

type Teacher = { id: string; username: string; fullName: string | null };
type Assigned = { teacher: { id: string; fullName: string | null; username: string } };

export default function TeacherAssign({ courseId }: { courseId: string }) {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [assigned, setAssigned] = useState<Assigned[]>([]);
  const [selected, setSelected] = useState("");

  async function load() {
    const [tRes, cRes] = await Promise.all([
      fetch("/api/users?role=TEACHER"),
      fetch(`/api/courses/${courseId}`),
    ]);
    const tData = await tRes.json();
    const cData = await cRes.json();
    setTeachers(tData.users ?? []);
    setAssigned(cData.course?.teachers ?? []);
  }
  useEffect(() => { load(); }, [courseId]);

  async function assign() {
    if (!selected) return;
    await fetch("/api/teacher-courses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ teacherId: selected, courseId }),
    });
    setSelected("");
    load();
  }

  async function unassign(teacherId: string) {
    await fetch("/api/teacher-courses", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ teacherId, courseId }),
    });
    load();
  }

  return (
    <div className="card p-5">
      <h2 className="font-medium text-ink-900">Assigned teachers</h2>
      <div className="mt-3 flex flex-wrap gap-2">
        {assigned.map((a) => (
          <span key={a.teacher.id} className="flex items-center gap-2 rounded-full bg-sand-100 px-3 py-1 text-sm">
            {a.teacher.fullName ?? a.teacher.username}
            <button className="text-red-600" onClick={() => unassign(a.teacher.id)}>×</button>
          </span>
        ))}
        {assigned.length === 0 && <p className="text-sm text-ink-400">No teachers assigned yet.</p>}
      </div>
      <div className="mt-4 flex gap-3">
        <select className="input" value={selected} onChange={(e) => setSelected(e.target.value)}>
          <option value="">Select a teacher…</option>
          {teachers.map((t) => (
            <option key={t.id} value={t.id}>{t.fullName ?? t.username}</option>
          ))}
        </select>
        <button className="btn-secondary shrink-0" onClick={assign}>Assign</button>
      </div>
    </div>
  );
}
