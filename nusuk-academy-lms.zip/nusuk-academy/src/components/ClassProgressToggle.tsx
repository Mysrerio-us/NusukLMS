"use client";

import { useState } from "react";

export default function ClassProgressToggle({
  classId,
  initialCompleted,
}: {
  classId: string;
  initialCompleted: boolean;
}) {
  const [completed, setCompleted] = useState(initialCompleted);
  const [loading, setLoading] = useState(false);

  async function toggle() {
    setLoading(true);
    const next = !completed;
    await fetch("/api/progress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ classId, completed: next }),
    });
    setCompleted(next);
    setLoading(false);
  }

  return (
    <button
      onClick={toggle}
      disabled={loading}
      className={`rounded-full px-3 py-1 text-xs font-medium transition ${
        completed ? "bg-emerald-100 text-emerald-800" : "bg-sand-100 text-ink-700 hover:bg-sand-200"
      }`}
    >
      {completed ? "✓ Completed" : "Mark as complete"}
    </button>
  );
}
