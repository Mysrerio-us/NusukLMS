import Link from "next/link";
import SignOutButton from "@/components/SignOutButton";

type NavItem = { href: string; label: string };

export default function DashboardShell({
  role,
  userName,
  navItems,
  children,
}: {
  role: string;
  userName: string;
  navItems: NavItem[];
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-sand-50 md:flex">
      <aside className="border-b border-sand-200 bg-white md:w-64 md:shrink-0 md:border-b-0 md:border-r">
        <div className="px-6 py-5">
          <p className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
            Nusuk Academy
          </p>
          <p className="mt-1 text-sm text-ink-400">{role}</p>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:overflow-visible md:pb-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium text-ink-700 hover:bg-sand-100"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="hidden border-t border-sand-200 px-6 py-4 md:block">
          <p className="mb-2 text-sm text-ink-700">{userName}</p>
          <SignOutButton />
        </div>
      </aside>
      <main className="flex-1 px-6 py-8 md:px-10">{children}</main>
    </div>
  );
}
