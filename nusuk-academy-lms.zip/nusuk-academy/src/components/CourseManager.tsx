"use client";

import { useEffect, useState } from "react";

type ClassItem = {
  id: string; title: string; description: string | null; date: string | null;
  video: { videoUrl: string; allowDownload: boolean } | null;
  liveClass: { zoomLink: string; scheduledAt: string } | null;
  resources: { id: string; title: string; fileUrl: string }[];
};
type ModuleItem = { id: string; title: string; classes: ClassItem[] };
type CourseDetail = { id: string; title: string; type: string; modules: ModuleItem[] };

export default function CourseManager({ courseId }: { courseId: string }) {
  const [course, setCourse] = useState<CourseDetail | null>(null);
  const [newModuleTitle, setNewModuleTitle] = useState("");
  const [newClassTitle, setNewClassTitle] = useState<Record<string, string>>({});
  const [openClassForm, setOpenClassForm] = useState<string | null>(null);

  async function load() {
    const res = await fetch(`/api/courses/${courseId}`);
    const data = await res.json();
    setCourse(data.course);
  }
  useEffect(() => { load(); }, [courseId]);

  async function addModule(e: React.FormEvent) {
    e.preventDefault();
    if (!newModuleTitle.trim()) return;
    await fetch("/api/modules", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ courseId, title: newModuleTitle }),
    });
    setNewModuleTitle("");
    load();
  }

  async function addClass(moduleId: string) {
    const title = newClassTitle[moduleId];
    if (!title?.trim()) return;
    await fetch("/api/classes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ moduleId, title }),
    });
    setNewClassTitle({ ...newClassTitle, [moduleId]: "" });
    load();
  }

  async function deleteModule(id: string) {
    if (!confirm("Delete this module and all its classes?")) return;
    await fetch(`/api/modules/${id}`, { method: "DELETE" });
    load();
  }

  async function deleteClass(id: string) {
    if (!confirm("Delete this class?")) return;
    await fetch(`/api/classes/${id}`, { method: "DELETE" });
    load();
  }

  async function attachVideo(classId: string) {
    const videoUrl = prompt("Paste the video embed/watch URL (YouTube, Drive, Bunny, etc.):");
    if (!videoUrl) return;
    const title = prompt("Video title:", "Recorded class") ?? "Recorded class";
    const allowDownload = confirm("Allow students to download this video?");
    let downloadUrl: string | undefined;
    if (allowDownload) downloadUrl = prompt("Direct download URL (optional, press cancel to skip):") ?? undefined;
    await fetch("/api/videos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ classId, title, videoUrl, allowDownload, downloadUrl: downloadUrl || undefined }),
    });
    load();
  }

  async function attachLive(classId: string) {
    const zoomLink = prompt("Paste the Zoom meeting link:");
    if (!zoomLink) return;
    const title = prompt("Live class title:", "Live session") ?? "Live session";
    const scheduledAt = prompt("Date & time (YYYY-MM-DDTHH:mm), e.g. 2026-07-10T18:00:");
    if (!scheduledAt) return;
    await fetch("/api/live-classes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ classId, title, zoomLink, scheduledAt }),
    });
    load();
  }

  async function addResource(classId: string, moduleId: string) {
    const title = prompt("Resource title:");
    if (!title) return;
    const fileUrl = prompt("File URL (upload to your storage first, then paste the public link):");
    if (!fileUrl) return;
    const type = (prompt("Type: PDF, DOCUMENT, IMAGE, AUDIO, LINK, OTHER", "PDF") ?? "PDF").toUpperCase();
    await fetch("/api/resources", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, fileUrl, type, classId, moduleId }),
    });
    load();
  }

  if (!course) return <p className="text-sm text-ink-400">Loading course…</p>;

  return (
    <div>
      <h1 className="font-display text-2xl text-ink-900">{course.title}</h1>
      <p className="mt-1 text-sm text-ink-400">{course.type} course · manage modules and classes below</p>

      <form onSubmit={addModule} className="mt-6 flex gap-3">
        <input className="input" placeholder="New module title (e.g. Module 1 - Aqeedah)"
          value={newModuleTitle} onChange={(e) => setNewModuleTitle(e.target.value)} />
        <button className="btn-primary shrink-0" type="submit">Add module</button>
      </form>

      <div className="mt-8 space-y-6">
        {course.modules.map((m) => (
          <div key={m.id} className="card p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-medium text-ink-900">{m.title}</h2>
              <button className="text-sm text-red-600 hover:underline" onClick={() => deleteModule(m.id)}>
                Delete module
              </button>
            </div>

            <ul className="mt-4 space-y-3">
              {m.classes.map((c) => (
                <li key={c.id} className="rounded-lg border border-sand-200 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-medium text-ink-800">{c.title}</p>
                    <button className="text-xs text-red-600 hover:underline" onClick={() => deleteClass(c.id)}>
                      Delete class
                    </button>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs">
                    <button className="btn-secondary py-1.5" onClick={() => attachVideo(c.id)}>
                      {c.video ? "Update video" : "+ Add recorded video"}
                    </button>
                    <button className="btn-secondary py-1.5" onClick={() => attachLive(c.id)}>
                      {c.liveClass ? "Update live class" : "+ Add live Zoom class"}
                    </button>
                    <button className="btn-secondary py-1.5" onClick={() => addResource(c.id, m.id)}>
                      + Add resource
                    </button>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2 text-xs text-ink-400">
                    {c.video && <span className="rounded-full bg-emerald-50 px-2 py-1 text-emerald-800">Video attached</span>}
                    {c.liveClass && <span className="rounded-full bg-sand-100 px-2 py-1 text-sand-800">Live class scheduled</span>}
                    {c.resources.length > 0 && <span className="rounded-full bg-sand-100 px-2 py-1">{c.resources.length} resource(s)</span>}
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-4 flex gap-3">
              <input className="input" placeholder="New class title (e.g. Class 1)"
                value={newClassTitle[m.id] ?? ""}
                onChange={(e) => setNewClassTitle({ ...newClassTitle, [m.id]: e.target.value })} />
              <button className="btn-secondary shrink-0" onClick={() => addClass(m.id)}>Add class</button>
            </div>
          </div>
        ))}
        {course.modules.length === 0 && (
          <p className="text-sm text-ink-400">No modules yet — add the first one above.</p>
        )}
      </div>
    </div>
  );
}
